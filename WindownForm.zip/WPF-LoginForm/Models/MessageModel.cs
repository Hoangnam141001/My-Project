﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_LoginForm.Models
{
    internal class MessageModel
    {
        public string username { get; set; }
        public string Message { get; set; }
    }
}
